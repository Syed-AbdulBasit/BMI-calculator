package com.example.bmiiicalculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
